package com.example.employee.demoEmployee.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class EmployeeDetails {
	
	
	@Id
	private int employeeId;
	private String name;
	private String role;
	private String address;
	private long salary;
	
	
	public EmployeeDetails(int employeeId, String name, String role, String address, long salary) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.role = role;
		this.address = address;
		this.salary = salary;
	}


	public EmployeeDetails() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public long getSalary() {
		return salary;
	}


	public void setSalary(long salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "EmployeeDetails [employeeId=" + employeeId + ", name=" + name + ", role=" + role + ", address="
				+ address + ", salary=" + salary + "]";
	}
	
	
	

}
