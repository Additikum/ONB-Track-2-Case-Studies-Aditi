package com.example.employee.demoEmployee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.employee.demoEmployee.entity.EmployeeDetails;
import com.example.employee.demoEmployee.service.EmployeeServiceImpl;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeServiceImpl employeeservice;
	
	
	@PostMapping("/add")
		public String add(@RequestBody EmployeeDetails employee)
		{
			employeeservice.addEmployee(employee);
			return "Employee Details added successfully";
		}
	
	@GetMapping("/getAll")
	public List<EmployeeDetails> getAll(){
		return employeeservice.getAllEmployee();

	}
	@GetMapping("/get/{id}")
	public EmployeeDetails  getById (@PathVariable("id") int id){
		return employeeservice.getByEmployeeId(id);

	}
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable("id") int id) {
		employeeservice.deleteEmployee(id);
		return "Employee Details Deleted Successfully";
	}
	@PutMapping("/put/{id}")
	 public String updateEmploee(@PathVariable("id") int id, @RequestBody EmployeeDetails employee)
	 {
		employeeservice.updateEmployee(employee, id);
		return "Updated Succesfully";
	}
	}


