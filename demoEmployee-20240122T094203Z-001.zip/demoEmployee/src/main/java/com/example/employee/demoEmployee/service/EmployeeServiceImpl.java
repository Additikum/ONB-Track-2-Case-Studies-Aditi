package com.example.employee.demoEmployee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee.demoEmployee.entity.EmployeeDetails;
import com.example.employee.demoEmployee.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	

	
	@Autowired
	EmployeeRepo employeerepo;
	public EmployeeServiceImpl(EmployeeRepo employeerepo) {
		this.employeerepo = employeerepo;
	}
	@Override
	public EmployeeDetails addEmployee(EmployeeDetails employee) {
	return  employeerepo.save(employee);
		
	}
	@Override
	public List<EmployeeDetails> getAllEmployee() {
		// TODO Auto-generated method stub
		return  employeerepo.findAll();
	}
	@Override
	public EmployeeDetails updateEmployee(EmployeeDetails employee, int id) {
		// TODO Auto-generated method stub
		
		  EmployeeDetails  emp =  employeerepo.findById(employee.getEmployeeId()).get() ;
			
		 emp.setName (emp.getName());
		 emp.setRole(emp.getRole());
		 emp.setSalary(emp.getSalary());
		  emp.setAddress(emp.getAddress());
			return  employeerepo.save( emp);
		
	}
	@Override
	public EmployeeDetails getByEmployeeId(int id) {
		// T 
		 return employeerepo.findById(id).orElse(null);
	}
	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		
		employeerepo.deleteById(id);
		
	}
	
	
}
